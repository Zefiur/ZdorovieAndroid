package ru.zdorovie.app;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import org.json.*;
import java.util.*;

public class HealthDb extends SQLiteOpenHelper {
    public HealthDb(Context c) { super(c, "zdorovie.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE profiles(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE readings(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,metric TEXT NOT NULL,value TEXT NOT NULL,unit TEXT,date TEXT NOT NULL,time TEXT,context TEXT,note TEXT)");
        db.execSQL("CREATE TABLE metric_defs(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,name TEXT NOT NULL,unit TEXT,type TEXT NOT NULL DEFAULT 'number',active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,title TEXT NOT NULL,date TEXT NOT NULL,done INTEGER NOT NULL DEFAULT 0,category TEXT)");
        db.execSQL("CREATE TABLE medications(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,name TEXT NOT NULL,dose TEXT,schedule TEXT,notes TEXT)");
        db.execSQL("CREATE TABLE meals(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,title TEXT NOT NULL,meal_type TEXT,date TEXT,recipe_json TEXT)");
        db.execSQL("CREATE TABLE cycle_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,start_date TEXT NOT NULL,end_date TEXT,intensity TEXT,symptoms TEXT,note TEXT)");
        db.execSQL("INSERT INTO profiles(name,created_at) VALUES('Основной профиль',datetime('now'))");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {}
    public long addProfile(String name) { ContentValues v=new ContentValues(); v.put("name",name); v.put("created_at",now()); return getWritableDatabase().insert("profiles",null,v); }
    public JSONArray profiles() { return rows("SELECT id,name FROM profiles ORDER BY id",null); }
    public long addReading(long pid,String metric,String value,String unit,String date,String time,String context,String note) {
        ContentValues v=new ContentValues(); v.put("profile_id",pid); v.put("metric",metric); v.put("value",value); v.put("unit",unit); v.put("date",date); v.put("time",time); v.put("context",context); v.put("note",note); return getWritableDatabase().insert("readings",null,v);
    }
    public JSONArray readings(long pid) { return rows("SELECT * FROM readings WHERE profile_id=? ORDER BY date DESC,time DESC,id DESC",new String[]{String.valueOf(pid)}); }
    public JSONArray readingsForDate(long pid,String date) { return rows("SELECT * FROM readings WHERE profile_id=? AND date=? ORDER BY time DESC,id DESC",new String[]{String.valueOf(pid),date}); }
    public long addMetric(long pid,String name,String unit,String type) { ContentValues v=new ContentValues(); v.put("profile_id",pid); v.put("name",name); v.put("unit",unit); v.put("type",type); return getWritableDatabase().insert("metric_defs",null,v); }
    public JSONArray metrics(long pid) { return rows("SELECT * FROM metric_defs WHERE profile_id=? AND active=1 ORDER BY name",new String[]{String.valueOf(pid)}); }
    public JSONObject exportAll() throws JSONException {
        JSONObject root=new JSONObject(); root.put("app","Здоровье"); root.put("schema_version",1); root.put("exported_at",now());
        JSONArray ps=profiles(); JSONArray out=new JSONArray();
        for(int i=0;i<ps.length();i++){ JSONObject p=ps.getJSONObject(i); long id=p.getLong("id"); JSONObject item=new JSONObject(); item.put("id",id); item.put("name",p.getString("name")); item.put("readings",readings(id)); item.put("metrics",metrics(id)); item.put("tasks",rows("SELECT * FROM tasks WHERE profile_id=?",new String[]{""+id})); item.put("medications",rows("SELECT * FROM medications WHERE profile_id=?",new String[]{""+id})); item.put("meals",rows("SELECT * FROM meals WHERE profile_id=?",new String[]{""+id})); item.put("cycle_entries",rows("SELECT * FROM cycle_entries WHERE profile_id=?",new String[]{""+id})); out.put(item); }
        root.put("profiles",out); return root;
    }
    public void importMerge(JSONObject root) throws Exception {
        if(root.optInt("schema_version",0)!=1) throw new Exception("Неподдерживаемая версия файла");
        JSONArray ps=root.optJSONArray("profiles"); if(ps==null) throw new Exception("В файле нет профилей");
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { for(int i=0;i<ps.length();i++){ JSONObject p=ps.getJSONObject(i); String name=p.optString("name","Импортированный профиль"); long pid=findOrCreateProfile(db,name);
            mergeRows(db,pid,p.optJSONArray("readings"),"readings",new String[]{"metric","value","unit","date","time","context","note"},new String[]{"metric","value","unit","date","time"});
            mergeRows(db,pid,p.optJSONArray("metrics"),"metric_defs",new String[]{"name","unit","type"},new String[]{"name"});
            mergeRows(db,pid,p.optJSONArray("tasks"),"tasks",new String[]{"title","date","done","category"},new String[]{"title","date"});
            mergeRows(db,pid,p.optJSONArray("medications"),"medications",new String[]{"name","dose","schedule","notes"},new String[]{"name","schedule"});
            mergeRows(db,pid,p.optJSONArray("meals"),"meals",new String[]{"title","meal_type","date","recipe_json"},new String[]{"title","meal_type","date"});
            mergeRows(db,pid,p.optJSONArray("cycle_entries"),"cycle_entries",new String[]{"start_date","end_date","intensity","symptoms","note"},new String[]{"start_date"});
        } db.setTransactionSuccessful(); } finally { db.endTransaction(); }
    }
    private long findOrCreateProfile(SQLiteDatabase db,String name){ Cursor c=db.rawQuery("SELECT id FROM profiles WHERE name=?",new String[]{name}); try{if(c.moveToFirst())return c.getLong(0);}finally{c.close();} ContentValues v=new ContentValues();v.put("name",name);v.put("created_at",now());return db.insert("profiles",null,v); }
    private void mergeRows(SQLiteDatabase db,long pid,JSONArray arr,String table,String[] fields,String[] keys)throws Exception{ if(arr==null)return; for(int i=0;i<arr.length();i++){JSONObject o=arr.getJSONObject(i);StringBuilder where=new StringBuilder("profile_id=?");ArrayList<String> args=new ArrayList<>();args.add(""+pid);for(String k:keys){where.append(" AND ").append(k).append("=?");args.add(o.isNull(k)?"":o.optString(k,""));}Cursor c=db.query(table,new String[]{"id"},where.toString(),args.toArray(new String[0]),null,null,null);boolean exists;try{exists=c.moveToFirst();}finally{c.close();}if(exists)continue;ContentValues v=new ContentValues();v.put("profile_id",pid);for(String f:fields){if(o.has(f)&&!o.isNull(f)){Object x=o.get(f);if(x instanceof Integer||x instanceof Long)v.put(f,((Number)x).longValue());else v.put(f,String.valueOf(x));}}db.insert(table,null,v);}}
    private JSONArray rows(String sql,String[] args){JSONArray a=new JSONArray();Cursor c=getReadableDatabase().rawQuery(sql,args);try{String[] cols=c.getColumnNames();while(c.moveToNext()){JSONObject o=new JSONObject();for(int i=0;i<cols.length;i++){try{o.put(cols[i],c.getString(i));}catch(Exception ignored){}}a.put(o);}}finally{c.close();}return a;}
    private String now(){return new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date());}
}
